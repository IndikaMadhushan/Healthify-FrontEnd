import { useState } from "react";
import {
  FaHome,
  FaNotesMedical,
  FaFileUpload,
  FaBell,
  FaUser
} from "react-icons/fa";


import { PatinetNavBar } from "../../components/PatientNavBar";
import RemindersPage from "../Reminders/RemindersPage";
import MyProfile from "./PatientProfilePage";
import PatientMediInfomation from "../PatientFormPage/PatientMediInfomation";
import MedicalReportsPage from "../MedicalReportsPage/MedicalReportsPage";
import SummaryPage from "./SummaryPage";



export default function Dashboard() {
  const [active, setActive] = useState("Summary");
  const [uploadCategory, setUploadCategory] = useState(null);
  const [userId] = useState("user_123"); // Replace with actual user ID from auth

  // Handle navigation to upload from Medical Reports page
  const handleNavigateToUpload = (category) => {
    setUploadCategory(category);
    setActive("Upload Report");
  };

  // Handle back from upload to Medical Reports
  const handleBackToReports = () => {
    setUploadCategory(null);
    setActive("Medical Reports");
  };

  return (
    <div className="h-screen bg-[#F2FBFA] flex flex-col">

      {/* TOP NAVBAR */}
      <PatinetNavBar />

      {/* MAIN LAYOUT */}
      <div className="flex flex-1 h-full overflow-hidden ">
        {/* LEFT SIDEBAR (DESKTOP ONLY) */} 
        <div className="hidden sm:flex lg:w-[260px] bg-[#EAF7F6] p-4 border-r border-[#D3F0ED] flex-col h-full overflow-hidden">
          <SidebarButton
            text="Summary"
            icon={<FaHome />}
            active={active}
            setActive={setActive}
          />
          <SidebarButton
            text="My Profile"
            icon={<FaUser />}
            active={active}
            setActive={setActive}
          />
          <SidebarButton
            text="Medical Info"
            icon={<FaNotesMedical />}
            active={active}
            setActive={setActive}
          />
          <SidebarButton
            text="Upload Report"
            icon={<FaFileUpload />}
            active={active}
            setActive={setActive}
          />
          <SidebarButton
            text="Reminders"
            icon={<FaBell />}
            active={active}
            setActive={setActive}
          />
        </div>

        {/* RIGHT CONTENT */}
        <div className="flex-1 py-6 px-4 bg-white overflow-y-auto">
          {renderContent(active)}
        </div>
      </div>

      {/* MOBILE BOTTOM NAV */}
      <div className="fixed bottom-0 left-0 right-0 sm:hidden bg-white border-t border-[#D3F0ED] flex justify-around py-2 z-50">
        <MobileNavButton
          icon={<FaHome />}
          text="Summary"
          active={active}
          setActive={setActive}
        />
        <MobileNavButton
          icon={<FaUser />}
          text="My Profile"
          active={active}
          setActive={setActive}
        />
        <MobileNavButton
          icon={<FaNotesMedical />}
          text="Medical Info"
          active={active}
          setActive={setActive}
        />
        <MobileNavButton
          icon={<FaFileUpload />}
          text="Reports"
          active={active === "Medical Reports" || active === "Upload Report"}
          setActive={() => setActive("Medical Reports")}
        />
        <MobileNavButton
          icon={<FaBell />}
          text="Reminders"
          active={active}
          setActive={setActive}
        />
      </div>
    </div>
  );
}

/* ---------------- SIDEBAR BUTTON ---------------- */

function SidebarButton({ text, icon, active, setActive }) {
  const isActive =
    active === text ||
    (text === "Medical Reports" && active === "Upload Report");

  return (
    <button
      onClick={() => setActive(text)}
      className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl mb-2 text-[15px] transition
        ${isActive
          ? "bg-[#18AAB0] text-white shadow"
          : "text-[#0F4F52] hover:bg-[#86C443]/20"
        }
      `}
    >
      <span className={`${isActive ? "text-white" : "text-[#18AAB0]"}`}>
        {icon}
      </span>
      {text}
    </button>
  );
}

/* ---------------- MOBILE NAV BUTTON ---------------- */

function MobileNavButton({ icon, text, active, setActive }) {
  const isActive = active === text;

  return (
    <button
      onClick={() => setActive(text)}
      className={`flex flex-col items-center text-[11px]
        ${isActive ? "text-[#18AAB0]" : "text-gray-500"}
      `}
    >
      <div className="text-[20px]">{icon}</div>
      {text}
    </button>
  );
}

/* ---------------- CONTENT RENDER ---------------- */

function renderContent(
  active,
  // handleNavigateToUpload,
  // uploadCategory,
  // handleBackToReports,
  // userId,
) {
  switch (active) {
    case "Summary":
      return <SummaryPage />;
    case "My Profile":
      return <MyProfile />;
     case "Upload Report":
       return <MedicalReportsPage />;

    case "Reminders":
      return <RemindersPage />;
    case "Medical Info":
       return <PatientMediInfomation />;
      
//     case "Upload Report":
//       return <PatientFormDoctorView />;
    default:
      return null;
  }
}


